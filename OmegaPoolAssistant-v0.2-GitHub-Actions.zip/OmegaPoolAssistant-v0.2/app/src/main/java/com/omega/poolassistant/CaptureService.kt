package com.omega.poolassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import java.util.concurrent.atomic.AtomicLong

/**
 * Continuous user-authorized screen capture.
 * Android requires fresh user consent for each MediaProjection session.
 */
class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        private const val CHANNEL_ID = "omega_capture"
        private const val NOTIFICATION_ID = 72
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var worker: HandlerThread? = null
    private var workerHandler: Handler? = null
    private var lastProcessedNs = AtomicLong(0L)
    private var frameCount = 0L
    private var lastReportNs = System.nanoTime()

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        if (resultCode == 0 || resultData == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
            projection?.registerCallback(projectionCallback, Handler(mainLooper))

            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi

            worker = HandlerThread("OmegaVisionWorker").also { it.start() }
            workerHandler = Handler(worker!!.looper)

            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            reader?.setOnImageAvailableListener({ imageReader ->
                val image = imageReader.acquireLatestImage() ?: return@setOnImageAvailableListener
                image.use { processFrame(it) }
            }, workerHandler)

            virtualDisplay = projection?.createVirtualDisplay(
                "OmegaPoolCapture",
                width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader?.surface, null, workerHandler
            )
        } catch (_: SecurityException) {
            stopSelf()
        } catch (_: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun processFrame(image: Image) {
        val now = System.nanoTime()
        val minInterval = 1_000_000_000L / 60L
        val previous = lastProcessedNs.get()
        if (now - previous < minInterval) return
        lastProcessedNs.set(now)
        frameCount++

        // Copy only the pixel plane metadata needed by the lightweight detector.
        // Image is closed by the caller immediately after this method returns.
        val plane = image.planes.firstOrNull() ?: return
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val width = image.width
        val height = image.height

        // Downsample for CPU-friendly analysis; the full-resolution frame is not retained.
        val sample = VisionEngine.analyze(buffer, width, height, pixelStride, rowStride, step = 6)
        PredictionStore.update(sample)

        if (now - lastReportNs >= 1_000_000_000L) {
            lastReportNs = now
            val fps = frameCount
            frameCount = 0
            // FPS is an observed processing count, not a promise of display refresh rate.
            sendBroadcast(Intent(VisionEngine.ACTION_STATUS).apply {
                setPackage(packageName)
                putExtra("processed_fps", fps)
                putExtra("detected_balls", sample.balls.size)
            })
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID, "OMEGA screen analysis", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("OMEGA Vision Engine")
            .setContentText("Captura de tela ativa • processamento local")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true).build()
    }

    override fun onDestroy() {
        virtualDisplay?.release()
        reader?.close()
        projection?.unregisterCallback(projectionCallback)
        projection?.stop()
        worker?.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
