package com.omega.poolassistant

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    private val captureRequest = 4102
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        status = TextView(this).apply {
            text = "OMEGA VISION ENGINE v0.2\nCaptura contínua • meta 60 FPS"
            textSize = 17f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 24)
        }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(8, 12, 22))
        }
        val title = TextView(this).apply {
            text = "OMEGA  /  VISION ENGINE"
            textSize = 23f
            setTextColor(Color.rgb(0, 245, 220))
            gravity = Gravity.CENTER
        }
        val overlayPermission = Button(this).apply {
            text = "1. Permitir exibição sobre outros apps"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else status.text = "Permissão de overlay concedida."
            }
        }
        val start = Button(this).apply {
            text = "2. Autorizar captura e iniciar"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    status.text = "Conceda primeiro a permissão de sobreposição."
                    return@setOnClickListener
                }
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
            }
        }
        val stop = Button(this).apply {
            text = "Parar captura e overlay"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                stopService(Intent(this@MainActivity, OverlayService::class.java))
                status.text = "OMEGA parado."
            }
        }
        panel.addView(title)
        panel.addView(status)
        panel.addView(overlayPermission)
        panel.addView(start)
        panel.addView(stop)
        setContentView(panel)
    }

    @Deprecated("Use Activity Result API in production")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            startService(Intent(this, OverlayService::class.java))
            status.text = "Captura autorizada. Análise contínua iniciada."
        } else {
            status.text = "Captura cancelada. Nenhuma tela foi capturada."
        }
    }
}
