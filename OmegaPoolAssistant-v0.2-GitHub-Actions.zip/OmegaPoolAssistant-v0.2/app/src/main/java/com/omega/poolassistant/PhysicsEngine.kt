package com.omega.poolassistant

import kotlin.math.hypot
import kotlin.math.roundToInt

data class Vec2(val x: Double, val y: Double) {
    operator fun plus(o: Vec2) = Vec2(x + o.x, y + o.y)
    operator fun minus(o: Vec2) = Vec2(x - o.x, y - o.y)
    operator fun times(k: Double) = Vec2(x*k, y*k)
    fun length() = hypot(x, y)
    fun normalized(): Vec2 {
        val n = length().coerceAtLeast(1e-9)
        return Vec2(x/n, y/n)
    }
}
data class Segment(val start: Vec2, val end: Vec2)
data class ShotPrediction(val cuePath: Segment, val objectPath: Segment, val powerPercent: Int)

object PhysicsEngine {
    /** Idealized ghost-ball geometry; requires calibrated ball/pocket coordinates. */
    fun straightShot(cue: Vec2, objectBall: Vec2, pocket: Vec2, radius: Double, scale: Double): ShotPrediction? {
        val direction = (pocket - objectBall).normalized()
        val ghost = objectBall - direction * (2.0 * radius)
        val distance = (ghost - cue).length()
        if (distance < 1e-6 || scale <= 0.0) return null
        return ShotPrediction(
            Segment(cue, ghost), Segment(objectBall, pocket),
            ((distance / scale) * 100.0).roundToInt().coerceIn(5, 100)
        )
    }

    fun reflect(direction: Vec2, normal: Vec2): Vec2 {
        val n = normal.normalized()
        return (direction - n * (2.0 * (direction.x*n.x + direction.y*n.y))).normalized()
    }
}
