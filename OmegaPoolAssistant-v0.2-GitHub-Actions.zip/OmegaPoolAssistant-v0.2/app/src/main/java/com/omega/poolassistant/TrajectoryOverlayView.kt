package com.omega.poolassistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class TrajectoryOverlayView(context: Context) : View(context) {
    private val cyan = Paint(3).apply { color = Color.rgb(0,255,220); strokeWidth = 4f; style = Paint.Style.STROKE }
    private val pink = Paint(3).apply { color = Color.rgb(255,45,190); strokeWidth = 4f; style = Paint.Style.STROKE }
    private val text = Paint(3).apply { color = Color.WHITE; textSize = 27f }
    private val amber = Paint(3).apply { color = Color.rgb(255,190,40); strokeWidth = 3f; style = Paint.Style.STROKE }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val state = PredictionStore.get()
        canvas.drawText("OMEGA VISION v0.2 • LIVE", 24f, 42f, text)
        if (state?.tableBounds != null) {
            val b = state.tableBounds
            canvas.drawRect(b[0]*width, b[1]*height, b[2]*width, b[3]*height, cyan)
            canvas.drawText("Mesa candidata", 24f, 78f, text)
        } else {
            canvas.drawText("Aguardando identificação da mesa", 24f, 78f, text)
        }
        canvas.drawText("Bolas confirmadas: ${state?.balls?.size ?: 0}", 24f, 114f, text)
        canvas.drawText("Trajetórias: aguardando calibração", 24f, 150f, text)
        // Lines are intentionally not fabricated until reliable ball/pocket detection exists.
        postInvalidateOnAnimation()
    }
}
