package com.omega.poolassistant

import java.nio.ByteBuffer
import kotlin.math.*

data class DetectedBall(val x: Float, val y: Float, val radius: Float, val confidence: Float)
data class VisionSnapshot(
    val width: Int,
    val height: Int,
    val tableBounds: FloatArray?,
    val balls: List<DetectedBall>,
    val note: String
)

/**
 * Lightweight heuristic detector.
 * It samples the frame and groups high-saturation/bright pixels as candidate ball regions.
 * This is NOT yet a trained or robust 8 Ball Pool detector; UI elements and effects can create
 * false positives. It intentionally reports candidates rather than claiming certainty.
 */
object VisionEngine {
    const val ACTION_STATUS = "com.omega.poolassistant.VISION_STATUS"

    fun analyze(
        source: ByteBuffer,
        width: Int,
        height: Int,
        pixelStride: Int,
        rowStride: Int,
        step: Int
    ): VisionSnapshot {
        val buf = source.duplicate()
        val xs = ArrayList<Int>()
        val ys = ArrayList<Int>()
        val colors = ArrayList<Int>()
        val rowPadding = rowStride - pixelStride * width

        var y = step
        while (y < height - step) {
            var x = step
            while (x < width - step) {
                val index = y * rowStride + x * pixelStride
                if (index + 2 < buf.limit()) {
                    val r = buf.get(index).toInt() and 0xff
                    val g = buf.get(index + 1).toInt() and 0xff
                    val b = buf.get(index + 2).toInt() and 0xff
                    val maxC = max(r, max(g, b))
                    val minC = min(r, min(g, b))
                    val saturation = if (maxC == 0) 0 else (maxC - minC) * 255 / maxC
                    // Candidate pixels: vivid ball colors or near-white/black ball highlights.
                    val vivid = saturation > 105 && maxC > 95
                    val neutral = saturation < 42 && (maxC > 205 || maxC < 55)
                    if (vivid || neutral) {
                        xs.add(x); ys.add(y); colors.add((r shl 16) or (g shl 8) or b)
                    }
                }
                x += step
            }
            y += step
        }

        // MVP placeholder: connected-component clustering and circle fitting are next iteration.
        // Avoid presenting unvalidated pixel candidates as actual ball detections.
        val bounds = estimateGreenTableBounds(buf, width, height, pixelStride, rowStride, step)
        return VisionSnapshot(width, height, bounds, emptyList(),
            "Mesa aproximada; detector de bolas/círculos ainda em calibração")
    }

    private fun estimateGreenTableBounds(
        buf: ByteBuffer, width: Int, height: Int, pixelStride: Int, rowStride: Int, step: Int
    ): FloatArray? {
        var minX = width; var minY = height; var maxX = -1; var maxY = -1
        var hits = 0
        var y = height / 8
        while (y < height * 7 / 8) {
            var x = width / 8
            while (x < width * 7 / 8) {
                val i = y * rowStride + x * pixelStride
                if (i + 2 < buf.limit()) {
                    val r = buf.get(i).toInt() and 255
                    val g = buf.get(i + 1).toInt() and 255
                    val b = buf.get(i + 2).toInt() and 255
                    // Broad green felt heuristic; many table themes require calibration.
                    if (g > r * 1.12 && g > b * 1.08 && g in 45..220) {
                        minX = min(minX, x); minY = min(minY, y)
                        maxX = max(maxX, x); maxY = max(maxY, y); hits++
                    }
                }
                x += step * 2
            }
            y += step * 2
        }
        if (hits < 80 || maxX <= minX || maxY <= minY) return null
        return floatArrayOf(
            minX.toFloat() / width, minY.toFloat() / height,
            maxX.toFloat() / width, maxY.toFloat() / height
        )
    }
}
