package com.omega.poolassistant

import java.util.concurrent.atomic.AtomicReference

object PredictionStore {
    private val latest = AtomicReference<VisionSnapshot?>(null)
    fun update(snapshot: VisionSnapshot) { latest.set(snapshot) }
    fun get(): VisionSnapshot? = latest.get()
}
