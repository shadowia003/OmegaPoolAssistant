plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.omega.poolassistant"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.omega.poolassistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }
}
